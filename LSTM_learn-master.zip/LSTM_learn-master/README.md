# LSTM_learn
a implement of LSTM using Keras for time series prediction regression problem
### Data
the data were from internet, this data was using for predict the number of people in a airline company, we use LSTM network to solve this problem
### Denpensies
for the implemention of code, we using Keras to establish LSTM network,  as well as using numpy, pandas, so before you runing this tutorial, it is strongly recommended you install Anaconda which is a package inclueded them all.
### open source protocol
MIT
### contact
author: jinfagang19@163.com
Central South University, Mr. Jin
